/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Landmark, Atom, Trophy, Globe2, Newspaper, ChevronRight, Play } from 'lucide-react';
import { CATEGORIES } from '../data/categories';
import { CategoryId, Question } from '../types';
import { soundFX } from '../utils/audio';

interface CategoriesScreenProps {
  questions: Question[];
  onSelectCategory: (catId: CategoryId) => void;
}

export const CategoriesScreen: React.FC<CategoriesScreenProps> = ({
  questions,
  onSelectCategory,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Landmark':
        return Landmark;
      case 'Atom':
        return Atom;
      case 'Trophy':
        return Trophy;
      case 'Globe2':
        return Globe2;
      case 'Newspaper':
        return Newspaper;
      default:
        return Landmark;
    }
  };

  const getQuestionCountForCategory = (catId: CategoryId) => {
    return questions.filter((q) => q.category === catId).length;
  };

  return (
    <div className="flex-1 flex flex-col bg-white text-slate-900 overflow-y-auto p-4 max-w-lg mx-auto w-full">
      {/* Title */}
      <div className="mb-4">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <span>विषयवार क्विज श्रेणियां</span>
        </h1>
        <p className="text-xs text-slate-600 mt-1">
          अपनी रुचि या आगामी प्रतियोगी परीक्षा के अनुसार विषय चुनें और 10 प्रश्नों का क्विज खेलें।
        </p>
      </div>

      {/* Categories List */}
      <div className="space-y-3 pb-6">
        {CATEGORIES.map((cat) => {
          const Icon = getIcon(cat.icon);
          const count = getQuestionCountForCategory(cat.id);

          return (
            <div
              key={cat.id}
              className="bg-blue-50/80 hover:bg-blue-50 rounded-2xl p-4 border border-blue-200/80 shadow-md transition-all duration-150 flex flex-col gap-3 group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center text-white shadow-md shadow-slate-950/30 shrink-0`}
                  >
                    <Icon className="w-6 h-6 stroke-[2]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white group-hover:text-blue-600 transition-colors">
                        {cat.nameHindi}
                      </h3>
                      <span className="text-[11px] text-slate-600 font-normal">
                        ({cat.nameEnglish})
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 mt-0.5 leading-relaxed">
                      {cat.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bottom strip with question count and Start CTA */}
              <div className="pt-2 border-t border-blue-200/60 flex items-center justify-between">
                <span className="text-[11px] text-blue-600/90 font-medium font-mono">
                  उपलब्ध प्रश्न: {count} प्रश्न
                </span>

                <button
                  onClick={() => {
                    soundFX.playTap();
                    onSelectCategory(cat.id);
                  }}
                  className="py-1.5 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-all active:scale-95 flex items-center gap-1.5 shadow"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>10 प्रश्न खेलें</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
