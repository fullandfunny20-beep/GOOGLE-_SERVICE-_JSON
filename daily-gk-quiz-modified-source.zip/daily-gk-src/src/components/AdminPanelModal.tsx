/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Plus, Edit2, Trash2, Shield, Search, RefreshCw, Check, Download, Upload, AlertCircle } from 'lucide-react';
import { Question, CategoryId } from '../types';
import { CATEGORIES } from '../data/categories';
import { getAdminPin, setAdminPin, resetQuestionsToDefault } from '../utils/storage';
import { soundFX } from '../utils/audio';

interface AdminPanelModalProps {
  isOpen: boolean;
  questions: Question[];
  onClose: () => void;
  onUpdateQuestions: (updated: Question[]) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  questions,
  onClose,
  onUpdateQuestions,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Add / Edit form state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);
  const [questionText, setQuestionText] = useState('');
  const [opt0, setOpt0] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [correctIndex, setCorrectIndex] = useState<0 | 1 | 2 | 3>(0);
  const [category, setCategory] = useState<CategoryId>('history');
  const [explanation, setExplanation] = useState('');
  const [difficulty, setDifficulty] = useState<'सरल' | 'मध्यम' | 'कठिन'>('मध्यम');

  const [notification, setNotification] = useState<string | null>(null);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const correctPin = getAdminPin();
    if (pinInput === correctPin) {
      setIsAuthenticated(true);
      setPinError(false);
      soundFX.playTap();
    } else {
      setPinError(true);
      soundFX.playWrong();
    }
  };

  const openAddForm = () => {
    setEditingQuestionId(null);
    setQuestionText('');
    setOpt0('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setCorrectIndex(0);
    setCategory('history');
    setExplanation('');
    setDifficulty('मध्यम');
    setIsFormOpen(true);
  };

  const openEditForm = (q: Question) => {
    setEditingQuestionId(q.id);
    setQuestionText(q.question);
    setOpt0(q.options[0]);
    setOpt1(q.options[1]);
    setOpt2(q.options[2]);
    setOpt3(q.options[3]);
    setCorrectIndex(q.correctIndex);
    setCategory(q.category);
    setExplanation(q.explanation);
    setDifficulty(q.difficulty || 'मध्यम');
    setIsFormOpen(true);
  };

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim() || !opt0.trim() || !opt1.trim() || !opt2.trim() || !opt3.trim()) {
      alert('कृपया प्रश्न और चारों विकल्प अनिवार्य रूप से भरें।');
      return;
    }

    const newQuestionObj: Question = {
      id: editingQuestionId || `custom_${Date.now()}`,
      question: questionText.trim(),
      options: [opt0.trim(), opt1.trim(), opt2.trim(), opt3.trim()],
      correctIndex,
      category,
      explanation: explanation.trim() || 'इस प्रश्न का सही उत्तर आधिकारिक सामान्य ज्ञान पाठ्यपुस्तकों पर आधारित है।',
      difficulty,
    };

    let updated: Question[];
    if (editingQuestionId) {
      updated = questions.map((q) => (q.id === editingQuestionId ? newQuestionObj : q));
      showNotification('प्रश्न सफलतापूर्वक अपडेट किया गया!');
    } else {
      updated = [newQuestionObj, ...questions];
      showNotification('नया प्रश्न सफलतापूर्वक जोड़ा गया!');
    }

    onUpdateQuestions(updated);
    setIsFormOpen(false);
    soundFX.playCorrect();
  };

  const handleDeleteQuestion = (id: string) => {
    if (window.confirm('क्या आप वाकई इस प्रश्न को स्थायी रूप से हटाना चाहते हैं?')) {
      const updated = questions.filter((q) => q.id !== id);
      onUpdateQuestions(updated);
      showNotification('प्रश्न हटा दिया गया!');
      soundFX.playTap();
    }
  };

  const handleResetDefaults = () => {
    if (window.confirm('क्या आप सभी प्रश्नों को डिफ़ॉल्ट प्रारंभिक प्रश्नों पर रीसेट करना चाहते हैं?')) {
      const defaults = resetQuestionsToDefault();
      onUpdateQuestions(defaults);
      showNotification('डिफ़ॉल्ट 60 प्रश्न पुनर्स्थापित किए गए!');
    }
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(questions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `daily_gk_hindi_questions_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleQuickTemplate = (preset: number) => {
    if (preset === 1) {
      setQuestionText('भारतीय संविधान की प्रारूप समिति (Drafting Committee) के अध्यक्ष कौन थे?');
      setOpt0('डॉ. भीमराव आंबेडकर');
      setOpt1('डॉ. राजेंद्र प्रसाद');
      setOpt2('पंडित जवाहरलाल नेहरू');
      setOpt3('सरदार वल्लभभाई पटेल');
      setCorrectIndex(0);
      setCategory('history');
      setExplanation('29 अगस्त 1947 को गठित 7 सदस्यीय प्रारूप समिति के अध्यक्ष भारत रत्न डॉ. भीमराव आंबेडकर थे।');
      setDifficulty('सरल');
    } else if (preset === 2) {
      setQuestionText('मानव शरीर में रक्तचाप (Blood Pressure) मापने के लिए किस यंत्र का उपयोग किया जाता है?');
      setOpt0('बैरोमीटर');
      setOpt1('स्फिग्मोमैनोमीटर');
      setOpt2('थर्मामीटर');
      setOpt3('लैक्टोमीटर');
      setCorrectIndex(1);
      setCategory('science');
      setExplanation('स्फिग्मोमैनोमीटर (Sphygmomanometer) का उपयोग रक्तचाप मापने हेतु किया जाता है। सामान्य रक्तचाप 120/80 mmHg होता है।');
      setDifficulty('मध्यम');
    }
  };

  // Filtered Questions list
  const filteredQuestions = questions.filter((q) => {
    const matchesCat = selectedCategoryFilter === 'all' || q.category === selectedCategoryFilter;
    const matchesSearch =
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.explanation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.options.some((o) => o.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white border border-blue-200 rounded-2xl overflow-hidden shadow-2xl text-slate-900 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-blue-50 border-b border-blue-100 shrink-0">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
              <Shield className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>एडमिन प्रश्न प्रबंधन पैनल</span>
                <span className="text-[10px] text-blue-600 bg-blue-600/10 px-2 py-0.5 rounded border border-blue-500/20">
                  {questions.length} कुल प्रश्न
                </span>
              </h2>
              <p className="text-[11px] text-slate-600">
                सामान्य ज्ञान प्रश्नों को जोड़ें, संपादित करें या हटाएं
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-600 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notification Banner */}
        {notification && (
          <div className="bg-emerald-600 text-white text-xs px-4 py-2 text-center font-bold flex items-center justify-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>{notification}</span>
          </div>
        )}

        {/* PIN Security Check */}
        {!isAuthenticated ? (
          <div className="p-8 flex flex-col items-center justify-center text-center max-w-sm mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 mb-4">
              <Shield className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">
              एडमिन सुरक्षा पिन (Security PIN)
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              प्रश्नों के प्रबंधन के लिए कृपया 4 अंकों का एडमिन पिन दर्ज करें। (डिफ़ॉल्ट पिन: <span className="font-mono text-blue-600 font-bold">1234</span>)
            </p>

            <form onSubmit={handlePinSubmit} className="w-full space-y-3">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="पिन दर्ज करें (उदा. 1234)"
                className="w-full text-center text-lg font-mono tracking-widest bg-blue-50 border border-blue-200 rounded-xl py-2 px-4 text-white focus:outline-none focus:border-blue-500"
                autoFocus
              />

              {pinError && (
                <div className="text-rose-400 text-xs font-semibold">
                  गलत पिन! कृपया पुनः प्रयास करें।
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow transition-colors"
              >
                एडमिन पैनल खोलें
              </button>
            </form>
          </div>
        ) : isFormOpen ? (
          /* Add / Edit Question Form */
          <div className="p-5 overflow-y-auto flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-blue-600 flex items-center gap-1.5">
                <Plus className="w-4 h-4" />
                <span>{editingQuestionId ? 'प्रश्न संपादित करें' : 'नया हिंदी GK प्रश्न जोड़ें'}</span>
              </h3>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-xs text-slate-600 hover:text-slate-800"
              >
                रद्द करें ✕
              </button>
            </div>

            {/* Quick preset helpers */}
            {!editingQuestionId && (
              <div className="bg-blue-50/80 p-2.5 rounded-xl border border-blue-200 mb-4 flex items-center gap-2 text-xs">
                <span className="text-slate-600 text-[11px] shrink-0">त्वरित नमूना:</span>
                <button
                  type="button"
                  onClick={() => handleQuickTemplate(1)}
                  className="px-2 py-1 bg-white hover:bg-blue-100 text-blue-600 rounded text-[11px] border border-blue-200"
                >
                  संविधान प्रश्न भरें
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickTemplate(2)}
                  className="px-2 py-1 bg-white hover:bg-blue-100 text-emerald-300 rounded text-[11px] border border-blue-200"
                >
                  विज्ञान प्रश्न भरें
                </button>
              </div>
            )}

            <form onSubmit={handleSaveQuestion} className="space-y-3.5 text-xs">
              {/* Question */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  प्रश्न पाठ (Question Text in Hindi):
                </label>
                <textarea
                  rows={2}
                  required
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="उदा. हड़प्पा सभ्यता किस नदी के किनारे स्थित है?"
                  className="w-full bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-slate-900 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Category & Difficulty */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    विषय श्रेणी (Category):
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as CategoryId)}
                    className="w-full bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-slate-900 text-xs focus:outline-none focus:border-blue-500"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nameHindi} ({c.nameEnglish})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    कठिनाई स्तर (Difficulty):
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as 'सरल' | 'मध्यम' | 'कठिन')}
                    className="w-full bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-slate-900 text-xs focus:outline-none focus:border-blue-500"
                  >
                    <option value="सरल">सरल</option>
                    <option value="मध्यम">मध्यम</option>
                    <option value="कठिन">कठिन</option>
                  </select>
                </div>
              </div>

              {/* 4 Options */}
              <div className="space-y-2">
                <label className="block font-semibold text-slate-800">
                  4 बहुविकल्पीय उत्तर (क, ख, ग, घ) एवं सही उत्तर चुनें:
                </label>

                {[
                  { label: '(क)', val: opt0, set: setOpt0, idx: 0 as const },
                  { label: '(ख)', val: opt1, set: setOpt1, idx: 1 as const },
                  { label: '(ग)', val: opt2, set: setOpt2, idx: 2 as const },
                  { label: '(घ)', val: opt3, set: setOpt3, idx: 3 as const },
                ].map((opt) => (
                  <div key={opt.idx} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="correctRadio"
                      checked={correctIndex === opt.idx}
                      onChange={() => setCorrectIndex(opt.idx)}
                      id={`opt_${opt.idx}`}
                      className="accent-amber-500 w-4 h-4 cursor-pointer"
                    />
                    <label
                      htmlFor={`opt_${opt.idx}`}
                      className={`font-bold text-xs shrink-0 cursor-pointer ${
                        correctIndex === opt.idx ? 'text-blue-600' : 'text-slate-600'
                      }`}
                    >
                      {opt.label}
                    </label>
                    <input
                      type="text"
                      required
                      value={opt.val}
                      onChange={(e) => opt.set(e.target.value)}
                      placeholder={`विकल्प ${opt.label}`}
                      className="flex-1 bg-blue-50 border border-blue-200 rounded-lg p-2 text-slate-900 text-xs focus:outline-none focus:border-blue-500"
                    />
                    {correctIndex === opt.idx && (
                      <span className="text-[10px] text-emerald-400 font-bold shrink-0 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                        सही उत्तर ✓
                      </span>
                    )}
                  </div>
                ))}
              </div>

              {/* Explanation */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  विस्तृत व्याख्या / तथ्य (Explanation in Hindi):
                </label>
                <textarea
                  rows={2}
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  placeholder="उदा. हड़प्पा की खोज 1921 में दयाराम साहनी द्वारा की गई थी..."
                  className="w-full bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-slate-900 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 py-2.5 bg-blue-50 hover:bg-blue-100 text-slate-700 font-semibold rounded-xl text-xs"
                >
                  रद्द करें
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs shadow"
                >
                  {editingQuestionId ? 'संशोधन सुरक्षित करें' : 'नया प्रश्न सहेजें'}
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Question Manager List View */
          <div className="flex-1 flex flex-col overflow-hidden p-4">
            {/* Top Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <button
                onClick={openAddForm}
                className="py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center gap-1.5 active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>नया प्रश्न जोड़ें</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportJSON}
                  className="p-2 bg-blue-50 hover:bg-blue-100 text-slate-700 rounded-xl text-xs transition-colors border border-blue-200"
                  title="बैकअप JSON डाउनलोड करें"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={handleResetDefaults}
                  className="p-2 bg-blue-50 hover:bg-blue-100 text-slate-700 rounded-xl text-xs transition-colors border border-blue-200"
                  title="डिफ़ॉल्ट 60 प्रश्नों पर रीसेट करें"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-600 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="प्रश्न या विकल्प खोजें..."
                  className="w-full bg-blue-50 border border-blue-100 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                className="bg-blue-50 border border-blue-100 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
              >
                <option value="all">सभी श्रेणियां ({questions.length})</option>
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nameHindi} ({questions.filter((q) => q.category === c.id).length})
                  </option>
                ))}
              </select>
            </div>

            {/* Questions Table/List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredQuestions.length === 0 ? (
                <div className="p-8 text-center text-slate-600 text-xs">
                  कोई प्रश्न नहीं मिला।
                </div>
              ) : (
                filteredQuestions.map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-3 bg-blue-50/80 rounded-xl border border-blue-200/80 hover:border-blue-200 transition-colors flex items-start justify-between gap-3"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-mono text-slate-600 font-bold">
                          #{idx + 1}
                        </span>
                        <span className="text-[10px] bg-white text-blue-600 px-2 py-0.5 rounded font-medium border border-blue-200">
                          {CATEGORIES.find((c) => c.id === q.category)?.nameHindi || q.category}
                        </span>
                        <span className="text-[10px] text-slate-600">
                          कठिनाई: {q.difficulty || 'मध्यम'}
                        </span>
                      </div>

                      <h4 className="text-xs font-semibold text-slate-900 leading-snug line-clamp-2">
                        {q.question}
                      </h4>

                      <div className="text-[11px] text-emerald-400 mt-1 truncate">
                        सही उत्तर: {q.options[q.correctIndex]}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => openEditForm(q)}
                        className="p-1.5 text-slate-700 hover:text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                        title="संपादित करें"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteQuestion(q.id)}
                        className="p-1.5 text-slate-600 hover:text-rose-400 hover:bg-blue-100 rounded-lg transition-colors"
                        title="हटाएं"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-5 py-3 bg-blue-50 border-t border-blue-100 flex items-center justify-between text-xs text-slate-600 shrink-0">
          <span>दैनिक सामान्य ज्ञान - हिंदी एडमिन सेवा</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-slate-800 rounded-lg text-xs"
          >
            बंद करें
          </button>
        </div>
      </div>
    </div>
  );
};
