/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

export const AndroidStatusBar: React.FC = () => {
  const [timeStr, setTimeStr] = useState('09:41');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const hrs = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      setTimeStr(`${hrs}:${mins}`);
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-8 px-4 flex items-center justify-between text-xs text-slate-700 bg-blue-50/70 backdrop-blur-md select-none shrink-0 z-30">
      {/* Time */}
      <span className="font-semibold tracking-tight text-[11px] font-mono">
        {timeStr}
      </span>

      {/* Android Center Camera Punch hole */}
      <div className="w-3.5 h-3.5 bg-black rounded-full border border-blue-100 shadow-inner" />

      {/* Status Icons */}
      <div className="flex items-center gap-1.5 text-slate-700">
        <span className="text-[10px] font-bold tracking-tight text-blue-600">5G</span>
        <Signal className="w-3 h-3" />
        <Wifi className="w-3 h-3" />
        <div className="flex items-center gap-0.5">
          <BatteryMedium className="w-3.5 h-3.5" />
          <span className="text-[9px] font-mono">98%</span>
        </div>
      </div>
    </div>
  );
};
