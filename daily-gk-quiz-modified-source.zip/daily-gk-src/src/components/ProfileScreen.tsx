/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Award, Flame, Target, Settings, Volume2, VolumeX, Shield, DollarSign, LogOut, Edit3, Check, Smartphone } from 'lucide-react';
import { soundFX, triggerHaptic } from '../utils/audio';

interface ProfileScreenProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  onOpenAdmin: () => void;
  onOpenAdMobPolicy: () => void;
  onOpenLoginModal: () => void;
}

const AVATAR_OPTIONS = ['👨‍🎓', '👩‍🎓', '👨‍🏫', '👩‍🏫', '🧑‍💻', '👨‍💼', '👩‍💼', '🇮🇳'];

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onUpdateUser,
  onOpenAdmin,
  onOpenAdMobPolicy,
  onOpenLoginModal,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(user.name);
  const [stateInput, setStateInput] = useState(user.state);
  const [examInput, setExamInput] = useState(user.targetExam);
  const [avatarInput, setAvatarInput] = useState(user.avatar);

  const accuracy = user.totalQuestionsAttempted > 0
    ? Math.round((user.totalCorrect / user.totalQuestionsAttempted) * 100)
    : 0;

  const handleSaveProfile = () => {
    soundFX.playTap();
    onUpdateUser({
      ...user,
      name: nameInput.trim() || 'प्रतियोगी छात्र',
      state: stateInput.trim() || 'भारत',
      targetExam: examInput.trim() || 'UPSC / SSC',
      avatar: avatarInput,
    });
    setIsEditing(false);
  };

  const handleToggleSound = () => {
    const nextVal = !user.soundEnabled;
    soundFX.setSoundEnabled(nextVal);
    if (nextVal) soundFX.playTap();
    onUpdateUser({ ...user, soundEnabled: nextVal });
  };

  const handleToggleVibration = () => {
    const nextVal = !user.vibrationEnabled;
    if (nextVal) triggerHaptic(40);
    onUpdateUser({ ...user, vibrationEnabled: nextVal });
  };

  return (
    <div className="flex-1 flex flex-col bg-white text-slate-900 overflow-y-auto p-4 max-w-lg mx-auto w-full">
      {/* Profile Header Card */}
      <div className="bg-blue-50/90 rounded-2xl p-4 border border-blue-200/80 shadow-md mb-4 relative">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="text-4xl p-2 bg-white rounded-2xl border border-blue-200 shadow-inner">
              {isEditing ? avatarInput : user.avatar}
            </div>

            <div>
              {isEditing ? (
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="अपना नाम दर्ज करें"
                  className="bg-white border border-blue-200 rounded-lg px-2.5 py-1 text-sm text-white font-bold w-full"
                />
              ) : (
                <h1 className="text-base font-bold text-white flex items-center gap-1.5">
                  <span>{user.name}</span>
                </h1>
              )}

              <div className="text-xs text-slate-600 mt-0.5">
                {isEditing ? (
                  <div className="flex gap-2 mt-1">
                    <input
                      type="text"
                      value={stateInput}
                      onChange={(e) => setStateInput(e.target.value)}
                      placeholder="राज्य / शहर"
                      className="bg-white border border-blue-200 rounded-lg px-2 py-0.5 text-xs text-slate-800 w-28"
                    />
                    <input
                      type="text"
                      value={examInput}
                      onChange={(e) => setExamInput(e.target.value)}
                      placeholder="लक्ष्य परीक्षा (उदा. UPSC)"
                      className="bg-white border border-blue-200 rounded-lg px-2 py-0.5 text-xs text-slate-800 w-36"
                    />
                  </div>
                ) : (
                  <span>
                    {user.state} · लक्ष्य: <span className="text-blue-600">{user.targetExam}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          <div>
            {isEditing ? (
              <button
                onClick={handleSaveProfile}
                className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow"
                title="सुरक्षित करें"
              >
                <Check className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => {
                  soundFX.playTap();
                  setIsEditing(true);
                }}
                className="p-2 bg-blue-100/60 hover:bg-blue-100 text-slate-700 rounded-xl transition-all"
                title="प्रोफ़ाइल संपादित करें"
              >
                <Edit3 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Avatar picker when editing */}
        {isEditing && (
          <div className="mt-3 pt-3 border-t border-blue-200/70">
            <span className="text-[11px] text-slate-600 block mb-1.5">अवतार चुनें:</span>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setAvatarInput(av)}
                  className={`text-2xl p-1.5 rounded-xl border transition-all ${
                    avatarInput === av
                      ? 'bg-blue-600/20 border-blue-500 scale-110'
                      : 'bg-white border-blue-100'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stats 4-Grid */}
      <div className="grid grid-cols-2 gap-2.5 mb-4">
        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center text-blue-600 font-bold">
            🏆
          </div>
          <div>
            <div className="text-[11px] text-slate-600">कुल स्कोर अंक</div>
            <div className="text-lg font-bold text-blue-600 font-mono">
              {user.totalPoints} अंक
            </div>
          </div>
        </div>

        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400">
            <Flame className="w-5 h-5 fill-orange-400" />
          </div>
          <div>
            <div className="text-[11px] text-slate-600">दैनिक स्ट्रीक</div>
            <div className="text-lg font-bold text-orange-400 font-mono">
              {user.currentStreakDays} दिन
            </div>
          </div>
        </div>

        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold font-mono">
            🎯
          </div>
          <div>
            <div className="text-[11px] text-slate-600">सटीकता प्रतिशत</div>
            <div className="text-lg font-bold text-emerald-400 font-mono">
              {accuracy}%
            </div>
          </div>
        </div>

        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold font-mono">
            📝
          </div>
          <div>
            <div className="text-[11px] text-slate-600">खेले गए क्विज</div>
            <div className="text-lg font-bold text-blue-400 font-mono">
              {user.quizzesPlayed}
            </div>
          </div>
        </div>
      </div>

      {/* Badges and Medals Showcase */}
      <div className="bg-blue-50/70 rounded-2xl p-4 border border-blue-200/80 mb-4">
        <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <Award className="w-4 h-4 text-blue-600" />
          <span>अर्जित उपलब्धियां एवं पदक</span>
        </h2>

        <div className="grid grid-cols-3 gap-2">
          {user.badges.map((b) => (
            <div
              key={b.id}
              className={`p-2.5 rounded-xl border flex flex-col items-center text-center transition-all ${
                b.unlocked
                  ? 'bg-amber-950/30 border-blue-500/40 text-slate-900 shadow-sm'
                  : 'bg-white/40 border-blue-100 text-slate-500 opacity-60'
              }`}
            >
              <div className="text-2xl mb-1">
                {b.unlocked ? '🏅' : '🔒'}
              </div>
              <div className="text-[11px] font-bold truncate w-full">
                {b.title}
              </div>
              <div className="text-[9px] text-slate-600 line-clamp-2 mt-0.5">
                {b.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* App Preferences & Tools */}
      <div className="bg-blue-50/70 rounded-2xl p-4 border border-blue-200/80 mb-4 space-y-3">
        <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Settings className="w-4 h-4 text-slate-600" />
          <span>ऐप सेटिंग्स एवं सुविधाएं</span>
        </h2>

        {/* Sound Toggle */}
        <div className="flex items-center justify-between py-1 border-b border-blue-200/60">
          <div className="flex items-center gap-2 text-xs text-slate-800">
            {user.soundEnabled ? <Volume2 className="w-4 h-4 text-blue-600" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            <span>ध्वनि प्रभाव (Sound Effects)</span>
          </div>
          <button
            onClick={handleToggleSound}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              user.soundEnabled ? 'bg-blue-600' : 'bg-blue-100'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                user.soundEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Vibration Toggle */}
        <div className="flex items-center justify-between py-1 border-b border-blue-200/60">
          <div className="flex items-center gap-2 text-xs text-slate-800">
            <Smartphone className="w-4 h-4 text-blue-600" />
            <span>हैप्टिक कंपन (Vibration Feedback)</span>
          </div>
          <button
            onClick={handleToggleVibration}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              user.vibrationEnabled ? 'bg-blue-600' : 'bg-blue-100'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                user.vibrationEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* AdMob Policy & Earnings */}
        <button
          onClick={() => {
            soundFX.playTap();
            onOpenAdMobPolicy();
          }}
          className="w-full flex items-center justify-between py-2 text-xs text-slate-800 hover:text-blue-600 transition-colors"
        >
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span>Google AdMob विज्ञापन नीति एवं राजस्व</span>
          </div>
          <span className="text-[11px] text-blue-600 font-medium">देखें →</span>
        </button>

        {/* Admin Panel Button */}
        <button
          onClick={() => {
            soundFX.playTap();
            onOpenAdmin();
          }}
          className="w-full flex items-center justify-between py-2 text-xs text-slate-800 hover:text-blue-600 transition-colors border-t border-blue-200/60 pt-2"
        >
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-purple-400" />
            <span>एडमिन पैनल (प्रश्न जोड़ें, संपादित करें, हटाएं)</span>
          </div>
          <span className="text-[11px] text-purple-400 font-mono font-bold">PIN 🔒</span>
        </button>
      </div>

      {/* Account Login / Switch */}
      <button
        onClick={() => {
          soundFX.playTap();
          onOpenLoginModal();
        }}
        className="w-full py-2.5 px-4 bg-blue-50 hover:bg-blue-100 text-slate-700 font-semibold text-xs rounded-xl border border-blue-200 transition-colors flex items-center justify-center gap-2 mb-6"
      >
        <LogOut className="w-4 h-4 text-rose-400" />
        <span>प्रोफ़ाइल बदलें / नया खाता लॉगिन</span>
      </button>
    </div>
  );
};
