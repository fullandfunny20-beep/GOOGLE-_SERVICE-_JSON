/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Info, ExternalLink } from 'lucide-react';
import { trackAdMobImpression } from '../utils/storage';

interface AdMobBannerProps {
  position?: 'top' | 'bottom' | 'inline';
  onOpenPolicy?: () => void;
}

const SAMPLE_ADS = [
  {
    title: 'UPSC & BPSC 2026 Test Series',
    tagline: 'भारत की सर्वश्रेष्ठ टेस्ट सीरीज से करें मजबूत तैयारी',
    cta: 'अभ्यास करें',
    sponsor: 'ज्ञान पब्लिकेशन',
    rating: '4.8 ★',
  },
  {
    title: 'SSC CGL & CHSL सामान्य अध्ययन',
    tagline: 'नवीनतम पैटर्न पर आधारित 10,000+ वस्तुनिष्ठ प्रश्न बैंक',
    cta: 'डाउनलोड करें',
    sponsor: 'एकेडमी बुक्स',
    rating: '4.9 ★',
  },
  {
    title: 'रेलवे RRB NTPC लाइव मॉक टेस्ट',
    tagline: 'दैनिक ऑल इंडिया रैंक और विस्तृत हिंदी समाधान प्राप्त करें',
    cta: 'शुरू करें',
    sponsor: 'परीक्षा पोर्टल',
    rating: '4.7 ★',
  },
];

export const AdMobBanner: React.FC<AdMobBannerProps> = ({ position = 'bottom', onOpenPolicy }) => {
  const [currentAdIndex, setCurrentAdIndex] = useState(0);

  useEffect(() => {
    trackAdMobImpression('banner');
    const interval = setInterval(() => {
      setCurrentAdIndex((prev) => (prev + 1) % SAMPLE_ADS.length);
    }, 18000);
    return () => clearInterval(interval);
  }, []);

  const ad = SAMPLE_ADS[currentAdIndex];

  return (
    <div
      className={`w-full bg-white/95 border-y border-blue-500/20 px-3 py-2 text-xs select-none ${
        position === 'bottom' ? 'border-t border-b-0' : ''
      }`}
    >
      <div className="max-w-md mx-auto flex items-center justify-between gap-3">
        {/* AdMob Identity badge */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="flex flex-col shrink-0">
            <span className="bg-blue-600/20 text-blue-600 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider border border-blue-500/30">
              Ad · AdMob
            </span>
            <span className="text-[9px] text-slate-500 mt-0.5 font-mono">
              Test Unit
            </span>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 truncate">
              <span className="font-semibold text-slate-900 text-xs truncate">
                {ad.title}
              </span>
              <span className="text-[10px] text-blue-600 font-medium shrink-0">
                {ad.rating}
              </span>
            </div>
            <p className="text-[10px] text-slate-600 truncate">
              {ad.tagline}
            </p>
          </div>
        </div>

        {/* CTA and Info */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              if (onOpenPolicy) onOpenPolicy();
            }}
            className="px-2.5 py-1 text-[11px] font-semibold text-slate-900 bg-blue-500 hover:bg-amber-300 rounded shadow-sm transition-colors active:scale-95 flex items-center gap-1 whitespace-nowrap"
          >
            <span>{ad.cta}</span>
            <ExternalLink className="w-2.5 h-2.5" />
          </button>

          {onOpenPolicy && (
            <button
              onClick={onOpenPolicy}
              title="AdMob एवं Google Play विज्ञापन नीति जानकारी"
              className="p-1 text-slate-600 hover:text-slate-800 transition-colors"
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
