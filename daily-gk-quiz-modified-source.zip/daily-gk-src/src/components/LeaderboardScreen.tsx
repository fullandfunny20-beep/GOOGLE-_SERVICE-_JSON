/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trophy, Flame, Award, Shield } from 'lucide-react';
import { LeaderboardEntry } from '../types';
import { soundFX } from '../utils/audio';

interface LeaderboardScreenProps {
  entries: LeaderboardEntry[];
  currentUserId: string;
}

export const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({
  entries,
  currentUserId,
}) => {
  const [filter, setFilter] = useState<'today' | 'week' | 'all'>('today');

  // Filter tabs
  const filterTabs = [
    { id: 'today' as const, label: 'आज (Daily)' },
    { id: 'week' as const, label: 'इस सप्ताह' },
    { id: 'all' as const, label: 'ऑल-टाइम' },
  ];

  // Top 3 Podium
  const top1 = entries[0];
  const top2 = entries[1];
  const top3 = entries[2];

  const currentUserEntry = entries.find((e) => e.isCurrentUser || e.id === currentUserId);

  return (
    <div className="flex-1 flex flex-col bg-white text-slate-900 overflow-y-auto p-4 max-w-lg mx-auto w-full">
      {/* Header */}
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-600/15 border border-blue-500/30 text-blue-600 text-xs font-bold mb-1">
          <Trophy className="w-3.5 h-3.5" />
          <span>दैनिक सामान्य ज्ञान लीडरबोर्ड</span>
        </div>
        <h1 className="text-xl font-extrabold text-white">
          शीर्ष प्रतियोगी छात्र
        </h1>
        <p className="text-xs text-slate-600 mt-0.5">
          हर सही उत्तर पर +10 अंक पाकर अपनी रैंकिंग सुधारें
        </p>
      </div>

      {/* Segmented Filter Control */}
      <div className="flex items-center justify-center p-1 bg-blue-50/80 rounded-xl border border-blue-100 mb-5">
        {filterTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              soundFX.playTap();
              setFilter(tab.id);
            }}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              filter === tab.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Top 3 Podium Cards */}
      <div className="grid grid-cols-3 gap-2 items-end mb-6 pt-6">
        {/* Rank 2 - Silver */}
        {top2 && (
          <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-2.5 flex flex-col items-center text-center shadow-md relative">
            <span className="absolute -top-3.5 bg-slate-400 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/20">
              #2 सिल्वर
            </span>
            <div className="text-3xl mb-1 mt-1">{top2.avatar}</div>
            <div className="text-xs font-bold text-slate-900 truncate w-full">
              {top2.name}
            </div>
            <div className="text-[10px] text-slate-600">{top2.state}</div>
            <div className="text-xs font-bold text-blue-600 font-mono mt-1">
              {top2.score} अंक
            </div>
          </div>
        )}

        {/* Rank 1 - Gold (Elevated) */}
        {top1 && (
          <div className="bg-gradient-to-b from-amber-900/60 via-slate-800 to-slate-850 border-2 border-blue-500 rounded-2xl p-3 flex flex-col items-center text-center shadow-xl shadow-amber-950/30 relative -translate-y-2">
            <span className="absolute -top-4 bg-blue-500 text-white text-[11px] font-extrabold px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1">
              <Trophy className="w-3 h-3 fill-slate-950" />
              #1 गोल्ड
            </span>
            <div className="text-4xl mb-1 mt-2">{top1.avatar}</div>
            <div className="text-xs font-extrabold text-blue-600 truncate w-full">
              {top1.name}
            </div>
            <div className="text-[10px] text-slate-600">{top1.state}</div>
            <div className="text-sm font-extrabold text-blue-600 font-mono mt-1">
              {top1.score} अंक
            </div>
            <div className="flex items-center gap-0.5 text-[9px] text-blue-600 font-medium mt-0.5">
              <Flame className="w-3 h-3 text-orange-400 fill-orange-400" />
              <span>{top1.streak} दिन</span>
            </div>
          </div>
        )}

        {/* Rank 3 - Bronze */}
        {top3 && (
          <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-2.5 flex flex-col items-center text-center shadow-md relative">
            <span className="absolute -top-3.5 bg-amber-700 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/20">
              #3 कांस्य
            </span>
            <div className="text-3xl mb-1 mt-1">{top3.avatar}</div>
            <div className="text-xs font-bold text-slate-900 truncate w-full">
              {top3.name}
            </div>
            <div className="text-[10px] text-slate-600">{top3.state}</div>
            <div className="text-xs font-bold text-blue-600 font-mono mt-1">
              {top3.score} अंक
            </div>
          </div>
        )}
      </div>

      {/* User Current Standing Highlight (if not top 3) */}
      {currentUserEntry && (
        <div className="bg-gradient-to-r from-amber-950/80 to-slate-900 border border-blue-500/50 rounded-xl p-3 mb-4 shadow flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white font-extrabold text-xs flex items-center justify-center font-mono">
              #{currentUserEntry.rank}
            </span>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>{currentUserEntry.name}</span>
                <span className="text-[10px] text-blue-600 bg-blue-600/20 px-1.5 py-0.2 rounded font-normal">
                  आप
                </span>
              </div>
              <div className="text-[10px] text-slate-600">
                सटीकता: {currentUserEntry.accuracy}% · स्ट्रीक: {currentUserEntry.streak} दिन
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-sm font-bold text-blue-600 font-mono">
              {currentUserEntry.score} अंक
            </div>
            <div className="text-[10px] text-slate-600">वर्तमान स्कोर</div>
          </div>
        </div>
      )}

      {/* Remaining Leaderboard Rows */}
      <div className="space-y-2 pb-6">
        <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
          सभी रैंक (All Rankings)
        </h3>

        {entries.map((item) => {
          const isUser = item.isCurrentUser || item.id === currentUserId;
          return (
            <div
              key={item.id}
              className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                isUser
                  ? 'bg-amber-950/40 border-blue-500/60 text-slate-900 ring-1 ring-amber-500/30'
                  : 'bg-blue-50/70 border-blue-200/60 text-slate-800'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="w-6 text-center font-bold text-xs font-mono text-slate-600 shrink-0">
                  #{item.rank}
                </span>
                <span className="text-2xl shrink-0">{item.avatar}</span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {item.name}
                  </div>
                  <div className="text-[10px] text-slate-600 truncate">
                    {item.state} · सटीकता {item.accuracy}%
                  </div>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-xs font-bold text-blue-600 font-mono">
                  {item.score} अंक
                </span>
                <div className="flex items-center justify-end gap-0.5 text-[9px] text-slate-600 font-mono">
                  <Flame className="w-2.5 h-2.5 text-orange-400" />
                  <span>{item.streak}d</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
