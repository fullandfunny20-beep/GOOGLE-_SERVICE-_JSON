import React, { useState } from 'react';
import { X, ShieldCheck } from 'lucide-react';
import { UserProfile } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  currentUser: UserProfile;
  onClose: () => void;
  onGoogleLogin: () => Promise<void>;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen, onClose, onGoogleLogin,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      await onGoogleLogin();
      onClose();
    } catch (err) {
      console.error('Google sign-in failed:', err);
      setError(err instanceof Error ? err.message : 'Google login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-blue-50/60 backdrop-blur-sm p-4">
      <section className="w-full max-w-sm rounded-3xl bg-white p-6 text-slate-900 shadow-2xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-blue-600">Daily GK Quiz</p>
            <h2 className="mt-1 text-xl font-extrabold">Sign in to continue</h2>
          </div>
          <button aria-label="Close login" onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <div className="my-7 rounded-2xl bg-blue-50 p-5 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-3xl text-white">🎓</div>
          <h3 className="font-bold text-blue-950">Your learning, saved</h3>
          <p className="mt-1 text-sm text-blue-800">Sign in to keep your quiz profile and progress on this device.</p>
        </div>
        <button onClick={handleGoogleLogin} disabled={loading} className="flex w-full items-center justify-center gap-3 rounded-xl bg-blue-600 px-4 py-3 font-bold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white text-sm font-black text-blue-600">G</span>
          {loading ? 'Connecting to Google…' : 'Continue with Google'}
        </button>
        {error && <p role="alert" className="mt-3 text-center text-sm text-red-600">{error}</p>}
        <p className="mt-5 flex items-center justify-center gap-2 text-xs text-slate-500"><ShieldCheck className="h-4 w-4 text-emerald-600" /> Secure sign-in powered by Firebase</p>
      </section>
    </div>
  );
};
