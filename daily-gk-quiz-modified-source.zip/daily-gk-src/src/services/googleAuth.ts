import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';

export async function signInWithGoogle() {
  if (!Capacitor.isNativePlatform()) {
    throw new Error('Google sign-in is configured for the Android app. Run it on an Android device or emulator.');
  }
  const result = await FirebaseAuthentication.signInWithGoogle();
  if (!result.user) throw new Error('Google did not return an authenticated user.');
  return result.user;
}

export async function getCurrentGoogleUser() {
  if (!Capacitor.isNativePlatform()) return null;
  const result = await FirebaseAuthentication.getCurrentUser();
  return result.user ?? null;
}

export async function signOutGoogle() {
  if (!Capacitor.isNativePlatform()) return;
  await FirebaseAuthentication.signOut();
}
