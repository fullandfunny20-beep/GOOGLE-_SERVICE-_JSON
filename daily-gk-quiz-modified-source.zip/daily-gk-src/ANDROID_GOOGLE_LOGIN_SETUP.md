# Android Google Login setup (Windows)

## 1. Install dependencies

Run PowerShell in this project folder:

```powershell
npm install
npx cap add android
```

If `android` already exists, do not run `npx cap add android` again.

## 2. Firebase Console

1. Create a Firebase project.
2. Add an Android app with package ID `com.dailygkquiz.app`.
3. Download `google-services.json` into `android/app/google-services.json`.
4. In Firebase Authentication, enable the Google provider.
5. Add the debug SHA-1 from `cd android; .\gradlew signingReport` to Firebase Project Settings > Your apps.
6. Download `google-services.json` again after configuring fingerprints if Firebase asks you to.

## 3. Google Services Gradle plugin

Follow the current Google Services plugin instructions for the generated Gradle DSL in `android/build.gradle` and `android/app/build.gradle`. Apply plugin `com.google.gms.google-services` (version `4.4.4` or the current version shown in Google's documentation) to the app module. Do not mix Groovy syntax with `.gradle.kts` Kotlin syntax.

## 4. Build and run

```powershell
npm run build
npx cap sync android
npx cap open android
```

In Android Studio, wait for Gradle sync, connect a device or start an emulator with Google Play services, then press Run.

## Notes

- The Google sign-in code is native Android-only; browser preview intentionally reports that Android is required.
- The profile and leaderboard still use the project's existing local storage. This change authenticates the user but does not yet sync leaderboard data to Firestore.
- Never commit `google-services.json` or signing keys to a public repository. Configure SHA-1 for both debug and Play App Signing/release certificates.
